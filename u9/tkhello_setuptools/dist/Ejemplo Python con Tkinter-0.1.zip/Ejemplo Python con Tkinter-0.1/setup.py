﻿from setuptools import setup
setup(name="Ejemplo Python con Tkinter",
	version="0.1",
	description="Ejemplo de ejecución de una aplicación Python con entorno gráfico Tkinter",
	author="José Luis Merino",
	author_email="jlmerdiez@gmail.com",
	url="www.anexpertforyou.com",
	license="GPL",
	scripts=["tkhello.py"],
	platforms=["Win", "Mac", "Linux"],
	long_description = """Un texto largo iría aquí."""
)